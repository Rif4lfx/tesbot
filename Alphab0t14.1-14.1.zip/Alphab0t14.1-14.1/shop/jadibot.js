const jadibut = () =>{
return`╭──「 📖  *JADIBOT*」
*Jadi Bot? Pc Owner*
`
}
exports.jadibut = jadibut