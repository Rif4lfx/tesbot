// jangan di ubah jika tidak punya group bot, takutnya eror
const gcbotwa = () =>{
	return`Join Aja Semua Fitur Bot Bisa Digunakan !

1. *Seele Bot*
https://chat.whatsapp.com/LYJHw4RsLmiKxpnXGz31T5


Jika ada link yang ke reset, silahkan hubungi
owner untuk meminta link yang baru
`
}
exports.gcbotwa = gcbotwa