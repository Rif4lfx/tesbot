const allpayment = (prefix) => {
return `PAYMENT BY RIF4LFX

*1. GOPAY
	ㅁ 0821 5720 7578
2. PULSA
	ㅁ 0821 5720 7578
	
Sebelum melakukan pembayaran ada baiknya anda menghubungi owner terlebih dahulu!
`
	}

exports.allpayment = allpayment
 