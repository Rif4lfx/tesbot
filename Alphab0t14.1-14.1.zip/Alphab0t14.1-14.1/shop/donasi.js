const donasibot = () => {
return `DONASI NYA KAKAK


1. GOPAY
	ㅁ 0821 5720 7578
2. PULSA
	ㅁ 0821 5720 7578
`
	}

exports.donasibot = donasibot
 